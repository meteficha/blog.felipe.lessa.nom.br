using System;
using System.Threading;
using Gtk;

namespace LeitordeRSS 
{
	/* Janela principal do programa. */
	public partial class MainWindow: Gtk.Window
	{	
		/* Um nó da lista de feeds. */
		[TreeNode(ListOnly=true)]
		protected class FeedListNode : TreeNode {
			/* O feed que nós representamos. */
			public Feed Feed {
				get;
				private set;
			}
			
			/* Constrói o nó para um feed. */
			public FeedListNode(Feed feed) {
				Feed = feed;
			}
			
			/* Valor que vai aparecer na coluna zero. */
			[TreeNodeValue(Column=0)]
			public String Text {
				get {
					return String.Format("<b>{0}</b>\n<small>{1}\n{2}</small>", 
					                     Feed.Name, Feed.Description, Feed.Link);
				}
			}
		}
		
		/* Nossa lista de feeds. */
		protected FeedList feedList;
		
		/* Stores dos NodeView's, o "Model" de MVC. */
		protected NodeStore feedStore;
		
		/* Construtor da janela principal. */
		public MainWindow (): base (Gtk.WindowType.Toplevel)
		{
			/* Este método é criado automaticamente pelo MonoDevelop
			 * para criar os widgets que nós desenhamos. */
			Build();
			
			/* Constrói a feedStore e a coluna do seu NodeView. */
			feedStore = new NodeStore(typeof(FeedListNode));
			nodeviewFeeds.NodeStore = feedStore;
			nodeviewFeeds.AppendColumn("Feed", new CellRendererText(), "markup", 0);
			
			/* Constrói nossa lista vazia de feeds. */
			feedList = new FeedList();
			feedList.Updated += delegate {
				Application.Invoke(delegate {
					UpdateFeeds();
				});
			};
		}
		
		/* Atualiza a lista de feeds mostrada ao usuário. */
		protected void UpdateFeeds() {
			// Limpa a lista.  Mais inteligente seria alterar
			// apenas o necessário, claro :).
			feedStore.Clear();
			
			// Adiciona todos os feeds.
			foreach (var feed in feedList.Feeds)
				feedStore.AddNode(new FeedListNode(feed));
		}
		
		/* Chamado quando a janela é fechada. */
		protected void OnDeleteEvent (object sender, DeleteEventArgs a)
		{
			Application.Quit();
			a.RetVal = true;
		}

		/* Método chamado quando a ação "Sair" é acionada. */
		protected virtual void OnSairActionActivated (object sender, System.EventArgs e)
		{
			Application.Quit();
		}

		/* Método chamado para a ação "Adicionar feed". */
		protected virtual void OnAdicionarFeedActionActivated (object sender, System.EventArgs e)
		{
			var dialog = new AddFeedDialog();
			dialog.Response += OnAddFeedResponse;
			dialog.Run();
			dialog.Destroy();
		}
		
		/* Chamado quando o usuário fecha o diálogo de adição de feed. */
		protected void OnAddFeedResponse (object obj, ResponseArgs args) {
			if (args.ResponseId == ResponseType.Ok) {
				// Adiciona o feed.
				var dialog = (AddFeedDialog) obj;
				var feed   = feedList.Add(dialog.Address);
				
				// Atualiza-o pela primeira vez em uma nova thread.
				new Thread(delegate () {
					feed.Refresh();
				}).Start();	
			}
		}

		/* Remove o feed selecionado, se houver. */
		protected virtual void OnRemoverFeedActionActivated (object sender, System.EventArgs e)
		{
			FeedListNode node = nodeviewFeeds.NodeSelection.SelectedNode as FeedListNode;
			if (node != null)
				feedList.Remove(node.Feed);
		}

		/* Atualiza todos os feeds. */
		protected virtual void OnAtualizarFeedsActionActivated (object sender, System.EventArgs e)
		{
			new Thread(delegate () {
				feedList.Refresh();
			}).Start();	
		}
	}
}