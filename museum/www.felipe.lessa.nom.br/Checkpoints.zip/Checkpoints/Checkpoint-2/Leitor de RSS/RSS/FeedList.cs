using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace LeitordeRSS
{
	/* Mantém a lista de Feeds que o usuário possui.
	 * Num programa real nós também deveriámos lidar
	 * com persistência da lista. */	
	public class FeedList
	{		
		/* Constrói a FeedList vazia. */
		public FeedList()
		{
		}
		
		/* Chama quaisquer listeners do nosso evento Updated. */
		protected void CallUpdated() 
		{
		}

		/* Atualiza todos os feeds. */
		public void Refresh() 
		{
		}
		
		/* Adiciona um novo feed à lista. */
		public Feed Add(String uri)
		{
			return null; /* TODO */
		}
		
		/* Remove um feed. */
		public void Remove(Feed feed) 
		{
		}
	}
}
