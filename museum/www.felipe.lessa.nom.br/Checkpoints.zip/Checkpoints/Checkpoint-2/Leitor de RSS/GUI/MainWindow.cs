using System;
using System.Threading;
using Gtk;

namespace LeitordeRSS 
{
	/* Janela principal do programa. */
	public partial class MainWindow: Gtk.Window
	{	
		/* Construtor da janela principal. */
		public MainWindow (): base (Gtk.WindowType.Toplevel)
		{
			/* Este método é criado automaticamente pelo MonoDevelop
			 * para criar os widgets que nós desenhamos. */
			Build();
		}
		
		/* Chamado quando a janela é fechada. */
		protected void OnDeleteEvent (object sender, DeleteEventArgs a)
		{
			Application.Quit();
			a.RetVal = true;
		}
	}
}