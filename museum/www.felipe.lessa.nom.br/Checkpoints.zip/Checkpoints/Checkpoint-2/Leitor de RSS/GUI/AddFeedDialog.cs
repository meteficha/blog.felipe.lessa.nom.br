using System;

namespace LeitordeRSS
{
	/* Janela utilizada para adicionar feeds ao programa. */
	public partial class AddFeedDialog : Gtk.Dialog
	{
		/* Construtor da janela */
		public AddFeedDialog()
		{
			/* Método criado pelo MonoDevelop. */
			this.Build();
		}
	}
}
