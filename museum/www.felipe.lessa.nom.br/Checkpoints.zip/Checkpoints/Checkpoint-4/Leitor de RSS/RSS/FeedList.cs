using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace LeitordeRSS
{
	/* Um delegate, análogo a um protótipo de função,
	 * usado para o evento Updated abaixo. */
	public delegate void FeedListUpdated();
	
	/* Mantém a lista de Feeds que o usuário possui.
	 * Num programa real nós também deveriámos lidar
	 * com persistência da lista. */	
	public class FeedList
	{		
		/* Evento acionado depois de todos os feeds serem atualizados,
		 * seja porque um feed foi adicionado ou removido, seja
		 * porque nós baixamos novamente suas informações. */
		public event FeedListUpdated Updated;
		
		/* Lista de feeds. */
		private IList<Feed> feeds;
		public IList<Feed> Feeds {
			get { 
				return new ReadOnlyCollection<Feed>(feeds); 
			}
		}
		
		/* Constrói a FeedList vazia. */
		public FeedList()
		{
			feeds = new List<Feed>();
		}
		
		/* Chama quaisquer listeners do nosso evento Updated. */
		protected void CallUpdated() 
		{
			// Se há alguém a ser avisado...
			if (Updated != null)
				// ..então avise-os agora.
				Updated();
		}

		/* Atualiza todos os feeds. */
		public void Refresh() 
		{
			// Atualiza cada feed sequencialmente.  Poderíamos
			// também atualizá-los concorrentemente num programa real.
			foreach (var feed in feeds)
				feed.Refresh();
			
			// Avisa a todos que a atualização foi concluída.
			CallUpdated();			
		}
		
		/* Adiciona um novo feed à lista.  Nós *não* 
		 * atualizamos o novo Feed com Refresh(). */
		public Feed Add(String uri)
		{
			// Cria o feed e o adiciona à nossa lista interna.
			var feed = new Feed(uri);
			feeds.Add(feed);
			
			// Avisa a todos.
			CallUpdated();
			
			// Retorna o feed que criamos.
			return feed;
		}
		
		/* Remove um feed. */
		public void Remove(Feed feed) 
		{
			// Remove o feed da lista interna.
			feeds.Remove(feed);
			
			// Avisa a todos.
			CallUpdated();
		}
	}
}
