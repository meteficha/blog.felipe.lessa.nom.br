using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Net;
using System.Xml;

namespace LeitordeRSS
{
	/* Representa um feed RSS, com metadados sobre o feed e
	 * zero ou mais items (notícias, posts...). */
	public class Feed
	{
		/* Nome do feed como definido pelo seu autor. */
		public String Name {
			get;
			private set;
		}
		
		/* Descrição do propósito do feed. */
		public String Description {
			get;
			private set;
		}
		
		/* Link associado ao feed.  Geralmente não é o endereço do feed,
		 * e sim o endereço do site de onde saiu o feed.  Também é
		 * definido pelo autor do feed. */
		public String Link {
			get;
			private set;
		}
		
		/* Endereço do feed passado pelo usuário quando ele o adicionou. 
		 * Numa aplicação real usaríamos o tipo de dados System.Uri. */
		public String Address {
			get;
			private set;
		}
		
		/* Items deste feed. */
		private IList<Item> items;
		public IList<Item> Items{
			get { 
				/* Nós retornamos uma coleção read-only
				 * para encapsular a lista de items sem
				 * que seja necessário copiá-la. */
				return new ReadOnlyCollection<Item>(items);
			}
			
			/* Não precisa de 'private set' porque nós explicitamente
			 * mantemos uma variável privada. */
		}
		
		
		/* Constrói um novo feed a partir apenas de seu endereço.
		 * Para obter os dados é necessário chamar Refresh(). */
		public Feed(String uri)
		{
			Address = uri;
			Name = "Carregando...";
			Description = "Por favor aguarde um momento.";
			Link = uri.ToString();
			items = new List<Item>();
		}
		
		/* Baixa o feed e faz o parse dele. */
		public void Refresh() {
			try {
				// Cria o documento e o lê de sua fonte.
				var doc = new XmlDocument();
				var reader = new XmlTextReader(Address);
				doc.Load(reader);
				
				// Obtém a primeira tag XML <channel> dentro da <rss>
				var channelNode = doc.SelectNodes("/rss/channel")[0];
				
				// Informações sobre o feed.
				Name        = GetValue(channelNode, "title");
				Description = GetValue(channelNode, "description");
				Link        = GetValue(channelNode, "link");
				
				// Limpa a lista de items
				items.Clear();
				
				// Adiciona os items deste XML
				foreach (XmlNode itemNode in channelNode.SelectNodes("item")) {
					// Informações sobre este item
					var itemTitle   = GetValue(itemNode, "title");
					var itemPubDate = GetValue(itemNode, "pubDate");
					var itemDescr   = GetValue(itemNode, "description");
					
					// Tenta fazer o parse como DateTime e imprimir como data curta.
					try {
						itemPubDate = DateTime.Parse(itemPubDate).ToShortDateString();
					} catch { }
					
					// Cria o item e o adiciona.
					var item = new Item(itemTitle, itemPubDate, itemDescr);
					items.Add(item);
				}
			} catch (Exception e) {
				// Pega qualquer exceção em qualquer parte e
				// mostra como erro na interface :).
				Console.WriteLine(e);
				Description = "Erro ao ler o feed.";
			}
		}
		
		/* Pequena função auxiliar para ler o texto dentro de uma tag. */
		private String GetValue(XmlNode node, String xpath) {
			var list = node.SelectNodes(xpath);
			if (list.Count > 0)
				return list[0].InnerText;
			else 
				return String.Empty; // Simplesmente ignoramos.
		}
	}
}
