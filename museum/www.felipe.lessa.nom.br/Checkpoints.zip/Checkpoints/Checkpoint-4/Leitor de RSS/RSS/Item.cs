using System;

namespace LeitordeRSS
{
	/* Um item de um canal RSS.  Geralmente é uma notícia
	 * ou um post, dependendo do que é o feed. */
	public class Item
	{
		/* Título do item. */
		public String Title {
			get;
			private set;
		}
		
		/* Data em que foi feito.  Não usamos DateTime
		 * apenas por preguiça de tratar erros :). */
		public String Date {
			get;
			private set;
		}
		
		/* Texto completo deste item. */
		public String Description {
			get;
			private set;
		}
		
		/* Constrói um novo item.  Depois da construção
		 * todos os seus dados são imutáveis. */
		public Item(String title, String date, String description)
		{
			Title = title;
			Date = date;
			Description = description;
		}
	}
}
