using System;
using System.Threading;
using Gtk;

namespace LeitordeRSS 
{
	/* Janela principal do programa. */
	public partial class MainWindow: Gtk.Window
	{	
		/* Nossa lista de feeds. */
		protected FeedList feedList;
		
		/* Construtor da janela principal. */
		public MainWindow (): base (Gtk.WindowType.Toplevel)
		{
			/* Este método é criado automaticamente pelo MonoDevelop
			 * para criar os widgets que nós desenhamos. */
			Build();
			
			/* Constrói nossa lista vazia de feeds. */
			feedList = new FeedList();
			feedList.Updated += delegate {
				Application.Invoke(delegate {
					UpdateFeeds();
				});
			};
		}
		
		/* Atualiza a lista de feeds mostrada ao usuário. */
		protected void UpdateFeeds() {
			/* TODO */
		}
		
		/* Chamado quando a janela é fechada. */
		protected void OnDeleteEvent (object sender, DeleteEventArgs a)
		{
			Application.Quit();
			a.RetVal = true;
		}

		/* Método chamado quando a ação "Sair" é acionada. */
		protected virtual void OnSairActionActivated (object sender, System.EventArgs e)
		{
			Application.Quit();
		}

		/* Método chamado para a ação "Adicionar feed". */
		protected virtual void OnAdicionarFeedActionActivated (object sender, System.EventArgs e)
		{
			var dialog = new AddFeedDialog();
			dialog.Response += OnAddFeedResponse;
			dialog.Run();
			dialog.Destroy();
		}
		
		/* Chamado quando o usuário fecha o diálogo de adição de feed. */
		protected void OnAddFeedResponse (object obj, ResponseArgs args) {
			if (args.ResponseId == ResponseType.Ok) {
				// Adiciona o feed.
				var dialog = (AddFeedDialog) obj;
				var feed   = feedList.Add(dialog.Address);
				
				// Atualiza-o pela primeira vez em uma nova thread.
				new Thread(delegate () {
					feed.Refresh();
				}).Start();	
			}
		}
	}
}