using System;
using System.Threading;
using Gtk;

namespace LeitordeRSS 
{
	/* Janela principal do programa. */
	public partial class MainWindow: Gtk.Window
	{	
		/* Um nó da lista de feeds. */
		[TreeNode(ListOnly=true)]
		protected class FeedListNode : TreeNode {
			/* O feed que nós representamos. */
			public Feed Feed {
				get;
				private set;
			}
			
			/* Constrói o nó para um feed. */
			public FeedListNode(Feed feed) {
				Feed = feed;
			}
			
			/* Valor que vai aparecer na coluna zero. */
			[TreeNodeValue(Column=0)]
			public String Text {
				get {
					return String.Format("<b>{0}</b>\n<small>{1}\n{2}</small>", 
					                     Feed.Name, Feed.Description, Feed.Link);
				}
			}
		}
		
		/* Um nó da lista de items. */
		[TreeNode(ListOnly=true)]
		protected class ItemListNode : TreeNode {
			/* O item que nós representamos.  Não podemos usar
			 * o nome "Item" porque ele existe na class TreeNode. */
			public Item RssItem {
				get;
				private set;
			}
			
			/* Construtor do nó. */
			public ItemListNode(Item item) {
				RssItem = item;
			}
			
			/* Valor da coluna zero, a data. */
			[TreeNodeValue(Column=0)]
			public String Date {
				get {
					return RssItem.Date;
				}
			}
			
			/* Valor da coluna um, o título. */
			[TreeNodeValue(Column=1)]
			public String Title {
				get {
					return RssItem.Title;
				}
			}
		}
		
		/* Nossa lista de feeds. */
		protected FeedList feedList;
		
		/* Stores dos NodeView's, o "Model" de MVC. */
		protected NodeStore feedStore;
		protected NodeStore itemStore;
		
		/* Construtor da janela principal. */
		public MainWindow (): base (Gtk.WindowType.Toplevel)
		{
			/* Este método é criado automaticamente pelo MonoDevelop
			 * para criar os widgets que nós desenhamos. */
			Build();
			
			/* Constrói a feedStore e a coluna do seu NodeView. */
			feedStore = new NodeStore(typeof(FeedListNode));
			nodeviewFeeds.NodeStore = feedStore;
			nodeviewFeeds.AppendColumn("Feed", new CellRendererText(), "markup", 0);
			
			/* Constrói o itemStore e suas colunas. */
			itemStore = new NodeStore(typeof(ItemListNode));
			nodeviewItems.NodeStore = itemStore;
			nodeviewItems.AppendColumn("Data",   new CellRendererText(), "text", 0);
			nodeviewItems.AppendColumn("Título", new CellRendererText(), "text", 1);			
			
			/* Constrói nossa lista vazia de feeds. */
			feedList = new FeedList();
			feedList.Updated += delegate {
				Application.Invoke(delegate {
					UpdateFeeds();
				});
			};
		}
		
		/* Atualiza a lista de feeds mostrada ao usuário. */
		protected void UpdateFeeds() {
			// Limpa a lista.  Mais inteligente seria alterar
			// apenas o necessário, claro :).
			feedStore.Clear();
			itemStore.Clear();
			textviewDescription.Buffer.Clear();
			
			// Adiciona todos os feeds.
			foreach (var feed in feedList.Feeds)
				feedStore.AddNode(new FeedListNode(feed));
		}
		
		/* Chamado quando a janela é fechada. */
		protected void OnDeleteEvent (object sender, DeleteEventArgs a)
		{
			Application.Quit();
			a.RetVal = true;
		}

		/* Método chamado quando a ação "Sair" é acionada. */
		protected virtual void OnSairActionActivated (object sender, System.EventArgs e)
		{
			Application.Quit();
		}

		/* Método chamado para a ação "Adicionar feed". */
		protected virtual void OnAdicionarFeedActionActivated (object sender, System.EventArgs e)
		{
			var dialog = new AddFeedDialog();
			dialog.Response += OnAddFeedResponse;
			dialog.Run();
			dialog.Destroy();
		}
		
		/* Chamado quando o usuário fecha o diálogo de adição de feed. */
		protected void OnAddFeedResponse (object obj, ResponseArgs args) {
			if (args.ResponseId == ResponseType.Ok) {
				// Adiciona o feed.
				var dialog = (AddFeedDialog) obj;
				var feed   = feedList.Add(dialog.Address);
				
				// Atualiza-o pela primeira vez em uma nova thread.
				new Thread(delegate () {
					feed.Refresh();
				}).Start();	
			}
		}

		/* Remove o feed selecionado, se houver. */
		protected virtual void OnRemoverFeedActionActivated (object sender, System.EventArgs e)
		{
			FeedListNode node = nodeviewFeeds.NodeSelection.SelectedNode as FeedListNode;
			if (node != null)
				feedList.Remove(node.Feed);
		}

		/* Atualiza todos os feeds. */
		protected virtual void OnAtualizarFeedsActionActivated (object sender, System.EventArgs e)
		{
			new Thread(delegate () {
				feedList.Refresh();
			}).Start();	
		}

		/* Método chamado quando o usuário muda a seleção
		 * do item da lista de feeds. */
		protected virtual void OnNodeviewFeedsCursorChanged (object sender, System.EventArgs e)
		{
			// Pega o nó selecionado e limpa a lista de items.
			var node = nodeviewFeeds.NodeSelection.SelectedNode as FeedListNode;
			itemStore.Clear();
			textviewDescription.Buffer.Clear();
			
			if (node != null) {
				// Há um item selecionado, mostra seus items.
				foreach (var item in node.Feed.Items)
					itemStore.AddNode(new ItemListNode(item));
			}
		}

		/* Método chamado para mostrar um item selecionado. */
		protected virtual void OnNodeviewItemsCursorChanged (object sender, System.EventArgs e)
		{
			// Pega o nó selecionado e limpa o texto.
			var node = nodeviewItems.NodeSelection.SelectedNode as ItemListNode;
			textviewDescription.Buffer.Clear();
			
			if (node != null) {
				// Mostra a sua descrição. 
				textviewDescription.Buffer.Text = node.RssItem.Description;
			}
		}
	}
}